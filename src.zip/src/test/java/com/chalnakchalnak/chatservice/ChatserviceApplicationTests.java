package com.chalnakchalnak.chatservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
